import React from 'react';


export default class ContactUs extends React.Component {

    render() {
        return (
            <React.Fragment>
                <h2>Hello Contact US page</h2>
            </React.Fragment>

        )
    }



}

