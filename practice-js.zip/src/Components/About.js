import React from 'react';
import {styles} from './About.css';


export default class About extends React.Component {
    constructor(props) {
        super(props)
    }

    render() {
        return (
            <React.Fragment>
               <h1 className="banner">Hello About page</h1>


            </React.Fragment>
        )
    }

}