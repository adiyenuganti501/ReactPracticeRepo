import React from "react";

export default class Footer extends React.Component {
    constructor(props) {
        super(props)
    }
    render() {
        return (
            <React.Fragment>
                <hr></hr>
                <h3>Copy Rights By {this.props.name}</h3>


            </React.Fragment>
        )
    }

}