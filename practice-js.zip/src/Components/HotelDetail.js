import React from 'react';
import axios from 'axios';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import {Link} from 'react-router-dom';
import { Container } from 'react-bootstrap';
const url = "https://developerfunnel.herokuapp.com/hotelsdetails";


export default class HotelDetails extends React.Component{
    constructor(){
        super()

        this.state={
            details:'',
           
        }
    }

    render(){

        let {details} = this.state
        return(
          <React.Fragment>
              <Container>
                  <TabPanel>
                      <h2>{this.state.details.name}</h2>    
                      <h2>HEllo Test DATA</h2>
                  </TabPanel>
              </Container>
          </React.Fragment>  
        )
    }



    async componentDidMount(){
        //var HotelId = this.props.match.params.id;
        var HotelId = window.location.href.split('/list/')[1]
        let response = await axios.get(`${url}/${HotelId}`)
        this.setState({details:response})
        console.log(response);
    }
}